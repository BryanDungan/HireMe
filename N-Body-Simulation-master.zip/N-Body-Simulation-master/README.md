N-Body-Simulation
=================

a cute, brute-force N-Body simulation  
  
Compilation: javac NBody.java  
Sample execution: java NBody 157788000.0 25000.0 < inputs/planets.txt  
Dependencies: StdDraw.java StdAudio.java  
Input files: ./inputs/*.txt  
